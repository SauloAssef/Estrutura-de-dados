import java.util.Arrays;
import java.util.Random;

public class Principal {
    public static int gerarNumero()
    {
        Random rand = new Random();
        int limite = 100;
        int int_random = rand.nextInt(limite);
        return int_random;
    }
    public static void main(String[] args) {
        System.out.println("\nTestando construtor Lista(int v) com a lista1");

        Lista lista1 = new Lista(-1);
        for(int i = 0; i < 3;i++)
        {
            lista1.append(new Elemento(gerarNumero()));
        }
        lista1.imprime();


        System.out.println("\nTestando construtor Lista(Lista lista) com a lista 2");
        Lista lista2 = new Lista(lista1);
        lista2.imprime();


        System.out.println("\nTestando construtor Lista(int[] v) com a lista 3");
        int v[]  = {0,1,6,9};
        Lista lista3 = new Lista(v);
        lista3.imprime();


        System.out.println("\nTestando metodo append(Eleemnto novo) com valor 30 na lista 3 ");
        lista3.append(new Elemento(30));
        lista3.imprime();


        System.out.println("\nTestando metodo preppend(Eleemnto novo) com valor 100 na lista 3");
        lista3.prepend(new Elemento(100));
        lista3.imprime();


        System.out.println("\nTestando metodo inserirPosicao(int v, int p) com valor 20 e posicao 1 na lista 3");
        lista3.inserirPosicao(20, 1);
        lista3.imprime();


        System.out.println("\nTestando metodo valorPosicao(int p) com posicao 5 na lista 3");
        System.out.println(lista3.valorPosicao(5));


        System.out.println("\nTestando metodo concatenar(Lista lista) a lista2 com a lista 3");
        lista2.concatenar(lista3);
        lista2.imprime();


        System.out.println("\nTestando metodo  inserirAposPosicao(int v, int p) com o valor 91 na posicao 6 na lista 3");
        lista3.inserirAposPosicao(91,6);
        lista3.imprime();


        System.out.println("\nTestando metodo inverter() com a lista1");
        lista1.inverter();
        lista1.imprime();


        System.out.println("\nTestando metodo ordenar() com a lista 3");
        lista3.ordenar();
        lista3.imprime();


        System.out.println("\nTestando metodo remover(int p) na posicao 0 na lista 3");
        lista3.remover(0);
        lista3.imprime();



        System.out.println("\nTestando metodo esvaziar() a lista 2");
        lista2.esvaziar();
        lista2.imprime();


        System.out.println("\nTestando metodo clone() a lista 1");
        Elemento aux = lista3.clone();
        while(aux != null){
            aux.imprime();
            aux = aux.getProximo();
        }


        System.out.println("\n Testando metodo indice(int v) com o valor 20 na lista 3");
        System.out.println("Posicao" + " --> " + lista3.indice( 20));


        System.out.println("\nTestando metodo tamanho() com a lista 3");
        System.out.println("Tamanho" + " --> " + lista3.tamanho());


        System.out.println("\nTestando metodo array() com a lista 3");
        int[] array = lista3.array();
        System.out.println(Arrays.toString(array));


        System.out.println("\nTestando metodo pertence(int v) com o valor 100 na lista 3");
        System.out.println(lista3.pertence(100));


        System.out.println("\nTestando metodo appendArray(int[] v) com valores {50,30,40,60} na lista 1");
        int vetor[]  ={50,30,40,60};
        lista1.appendArray(vetor);
        lista1.imprime();


        System.out.println("\nTestando metodo prependArray(int[] v) com valores {10,20,30,40} na lista 1");
        int vetor2[]  ={10,20,30,40};
        lista1.prependArray(vetor2);
        lista1.imprime();


        System.out.println("\nTestando metodo inserirListaPosicao(Lista lista, int p) Inserir Lista 5 na posicao 1 da Lista 4");
        Lista lista4 = new Lista(new int[] {14,17,});
        System.out.println("Lista 4:");
        lista4.imprime();
        Lista lista5 = new Lista(new int[] {33,11,});
        System.out.println("Lista 5:");
        lista5.imprime();
        System.out.println("\nInserir Lista 5 na posicao 1 da Lista 4-->");
        lista4.inserirListaPosicao(lista5,1);
        lista4.imprime();


        System.out.println("\nTestando metodo inserirArrayPosicao(int[] v, int p) vetor3 na posicao 2 da lista 4");
        int vetor3[] = {59,29,49};
        lista4.inserirArrayPosicao(vetor3,2);
        lista4.imprime();


        System.out.println("\nTestando metodo contar(int v) contar quantas vezes o valor 11 aparece na lista 6");
        Lista lista6 = new Lista(new int[] {0,11,11,11,98});
        System.out.println("Apareceu --> " + lista6.contar(11) + " vezes ");



    }

}

