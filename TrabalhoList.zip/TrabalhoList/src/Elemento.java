public class Elemento {

    public int valor;
    private Elemento proximo;

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    public Elemento(int v){
        this.valor = v;
        this.proximo = null;
    }
    public void setProximo(Elemento e)
    {
        this.proximo = e;
    }
    public Elemento getProximo()
    {
        return this.proximo;
    }
    public void imprime()
    {
        System.out.println("valor = " + this.valor);

    }
}
