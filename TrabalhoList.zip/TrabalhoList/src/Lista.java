public class Lista {

    public Elemento primeiro;
    private Elemento ultimo;

    //CONSTRUTORES -->
    public Lista() {
        primeiro = null;
        ultimo = null;
    }
    public Lista(int v) {
        primeiro = new Elemento(v);
        ultimo = primeiro;
    }
    public Lista(Lista lista) {

        Elemento aux = lista.primeiro;
        while (aux != null) {

            this.append(new Elemento(aux.getValor()));

            aux = aux.getProximo();
        }

    }
    public Lista(int v []) {

        if(v.length == 0) {
            System.out.println("[ERR0] Não há elementos no array!");
            return;
        }

        primeiro = new Elemento( v[0] );
        ultimo = primeiro;

        for (int i = 1; i < v.length; i++) {

            this.append(new Elemento(v[i]));

        }
    }


    //METODOS -->
    public void append(Elemento novo) {
        if(primeiro == null) {
            primeiro = ultimo = novo;
        }else {
            this.ultimo.setProximo(novo);
            this.ultimo = novo;
        }
    }

    public void prepend(Elemento novo) {
        if(primeiro == null) {
            primeiro = ultimo = novo;
        }else {
            novo.setProximo(this.primeiro);
            primeiro = novo;
        }

    }

    public void inserirPosicao(int v, int p) {
        int count = 0;
        Elemento aux = this.primeiro;
        Elemento anterior = null;

        while (aux != null) {
            if(count == p) {

                Elemento novo = new Elemento(v);
                novo.setProximo(aux);

                if(this.primeiro == aux) {

                    this.primeiro = novo;

                }else {

                    anterior.setProximo(novo);
                }

                return;
            }
            count++;
            anterior = aux;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
    }

    public Integer valorPosicao(int p){
        if(p < 0){
            System.out.println("[ERR0] Essa posição não existe na lista");
            return null;
        }
        int count = 0;
        Elemento aux = this.primeiro;

        while(aux != null){
            if(count == p){
                return aux.getValor();

            }
            count++;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
        return null;
    }

    public void concatenar(Lista lista){
        ultimo.setProximo(lista.primeiro);
        ultimo = lista.ultimo;


    }

    public void inserirAposPosicao(int v, int p) {
        if(p < 0){
            System.out.println("[ERR0] Essa posição não existe na lista");
            return;
        }

        int count = 0;
        Elemento aux = this.primeiro;

        while (aux != null) {
            if(count == p) {

                Elemento novo = new Elemento(v);

                if(aux == this.ultimo) {
                    aux.setProximo(novo);
                    this.ultimo = novo;

                }else {
                    novo.setProximo(aux.getProximo());
                    aux.setProximo(novo);
                }

                return;
            }
            count++;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
    }

    public void inverter(){
        Lista listaAux = new Lista();
        Elemento aux = this.primeiro;
         while(aux != null){
             listaAux.prepend(new Elemento(aux.getValor()));
             aux = aux.getProximo();
         }
        this.primeiro = listaAux.primeiro;
         this.ultimo = listaAux.ultimo;
    }

    public void ordenar() {

        Elemento auxExterno = this.primeiro;


        while (auxExterno != null) {

            Elemento min = auxExterno;

            Elemento auxInterno = auxExterno.getProximo();

            while(auxInterno != null) {

                if(auxInterno.getValor() < min.getValor()) {
                    min = auxInterno;
                }

                auxInterno = auxInterno.getProximo();
            }

            int auxTroca = min.getValor();
            min.setValor( auxExterno.getValor() );
            auxExterno.setValor(auxTroca);

            auxExterno = auxExterno.getProximo();
        }

    }

    public void remover(int p){
        Elemento aux = this.primeiro;
        Elemento anterior = null;
        int count = 0;
        while(aux != null){

            if(count == p){
                if(aux == primeiro && aux == ultimo){
                    this.primeiro = null;
                    this.ultimo = null;
                    return;
                }

                if(aux == primeiro){
                    this.primeiro = aux.getProximo();
                    return;
                }
                if(aux == ultimo){
                    ultimo = anterior;
                    ultimo.setProximo(null);
                    return;
                }
                anterior.setProximo(aux.getProximo());
                return;
            }
            count++;
            anterior = aux;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
    }

    public void esvaziar(){
        this.primeiro = null;
        this.ultimo = null;
    }

    public Elemento clone(){

        return this.primeiro;

    }

    public int indice(int v) {
        int count = 0;
        Elemento aux = this.primeiro;

        while (aux != null) {
            if (aux.getValor() == v) {
                return count;

            }
            count++;
            aux = aux.getProximo();

        }
        return -1;
    }

    public int tamanho(){
        int count = 0;
        Elemento aux = this.primeiro;


        while(aux != null){
            count++;
            aux = aux.getProximo();
        }

        return count;
    }

    public int[] array(){
        int[] array = new int[tamanho()];
        int count = 0;

        Elemento aux = this.primeiro;


        while(aux != null){
            array[count] = aux.getValor();
            count++;
            aux = aux.getProximo();
        }


        return array;
    }

    public boolean pertence(int v){

        Elemento aux = this.primeiro;


        while(aux != null){
            if(aux.getValor() == v){
                return true;
            }

            aux = aux.getProximo();
        }


        return false;
    }

    public void appendArray(int[] v){
        for (int i = 0; i < v.length; i++) {

            this.append(new Elemento(v[i]));

        }
    }

    public void prependArray(int[] v){
        for (int i = v.length - 1; i >= 0; i--) {

            this.prepend(new Elemento(v[i]));

        }
    }

    public void inserirListaPosicao(Lista lista, int p){
        int count = 0;
        Elemento aux = this.primeiro;
        Elemento anterior = null;

        if(lista.primeiro == null){
            return;
        }

        while (aux != null) {
            if(count == p) {


                lista.ultimo.setProximo(aux);

                if(this.primeiro == aux) {

                    this.primeiro = lista.primeiro;

                }else {

                    anterior.setProximo(lista.primeiro);
                }

                return;
            }
            count++;
            anterior = aux;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
    }

    public void inserirArrayPosicao(int[] v, int p){

        if(p < 0){
            System.out.println("[ERR0] Essa posição não existe na lista");
            return;
        }

        int count = 0;
        Elemento aux = this.primeiro;
        Lista lista = new Lista(v);

        while (aux != null) {
            if(count == p) {

                if(aux == this.ultimo) {
                    aux.setProximo(lista.primeiro);
                    this.ultimo = lista.ultimo;

                }else {
                    lista.ultimo.setProximo(aux.getProximo());
                    aux.setProximo(lista.primeiro);
                }

                return;
            }
            count++;
            aux = aux.getProximo();
        }
        System.out.println("[ERR0] Essa posição não existe na lista");
    }

    public int contar(int v){

        Elemento aux = this.primeiro;
        int count = 0;

        while(aux != null){
            if(aux.getValor() == v){
                count++;
            }

            aux = aux.getProximo();
        }


        return count;
    }

    public void imprime() {
        if(primeiro == null && ultimo == null){
            System.out.println("Esta Lista esta vazia!!!");
        }
        Elemento aux = this.primeiro;
        while(aux != null)
        {
            aux.imprime();
            aux = aux.getProximo();
        }
    }
}
